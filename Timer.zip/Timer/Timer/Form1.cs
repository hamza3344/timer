﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Timer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }
        public void timer()
        {
            int second=Convert.ToInt16(lblsec.Text)+1;
            if(second==60) {
                lblsec.Text = "0";
                int minute=Convert.ToInt16(lblmin.Text)+1;
                if(minute==60)
                {
                    lblmin.Text = "0";
                    int hour=Convert.ToInt16(lblhrs.Text)+1;
                    if(hour==24)
                    {
                        lblhrs.Text = "0";
                        int day=Convert.ToInt16(lbldays.Text)+1;
                        lbldays.Text = day.ToString();
                    }
                    else
                    {
                        lblhrs.Text = hour.ToString();
                    }
                }
                else
                {
                    lblmin.Text = "0";
                }
            }
            else
            {
                lblsec.Text=second.ToString();
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled= true;
        }
    }
}
