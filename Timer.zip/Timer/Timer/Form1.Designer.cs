﻿namespace Timer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblsec = new System.Windows.Forms.Label();
            this.lblmin = new System.Windows.Forms.Label();
            this.lblhrs = new System.Windows.Forms.Label();
            this.lbldays = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(566, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seconds";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(466, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Minutes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(362, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hours";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(274, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Days";
            // 
            // lblsec
            // 
            this.lblsec.AutoSize = true;
            this.lblsec.Location = new System.Drawing.Point(569, 227);
            this.lblsec.Name = "lblsec";
            this.lblsec.Size = new System.Drawing.Size(13, 13);
            this.lblsec.TabIndex = 4;
            this.lblsec.Text = "0";
            this.lblsec.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblmin
            // 
            this.lblmin.AutoSize = true;
            this.lblmin.Location = new System.Drawing.Point(466, 227);
            this.lblmin.Name = "lblmin";
            this.lblmin.Size = new System.Drawing.Size(13, 13);
            this.lblmin.TabIndex = 5;
            this.lblmin.Text = "0";
            // 
            // lblhrs
            // 
            this.lblhrs.AutoSize = true;
            this.lblhrs.Location = new System.Drawing.Point(362, 227);
            this.lblhrs.Name = "lblhrs";
            this.lblhrs.Size = new System.Drawing.Size(13, 13);
            this.lblhrs.TabIndex = 6;
            this.lblhrs.Text = "0";
            // 
            // lbldays
            // 
            this.lbldays.AutoSize = true;
            this.lbldays.Location = new System.Drawing.Point(274, 227);
            this.lbldays.Name = "lbldays";
            this.lbldays.Size = new System.Drawing.Size(13, 13);
            this.lbldays.TabIndex = 7;
            this.lbldays.Text = "0";
            // 
            // timer1
            // 
            this.timer1.Interval = 997;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbldays);
            this.Controls.Add(this.lblhrs);
            this.Controls.Add(this.lblmin);
            this.Controls.Add(this.lblsec);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblsec;
        private System.Windows.Forms.Label lblmin;
        private System.Windows.Forms.Label lblhrs;
        private System.Windows.Forms.Label lbldays;
        private System.Windows.Forms.Timer timer1;
    }
}

